package prvi;

public class Konobar extends Zaposleni {

    public Konobar(int id, String ime, String prezime, double plataPoSatu, double ukupanBrojSati) {
        super(id, ime, prezime, plataPoSatu, ukupanBrojSati);
    }

    @Override
    public double obracunPlate() {
        double osnovnaPlata = getPlataPoSatu() * getUkupanBrojSati();
        if (getUkupanBrojSati() > 160) {
            double prekovremeniSati = getUkupanBrojSati() - 160;
            return osnovnaPlata + prekovremeniSati * (getPlataPoSatu() * 0.20);
        }
        return osnovnaPlata;
    }
}
