package prvi;

public abstract class Zaposleni {
    private int id;
    private String ime;
    private String prezime;
    private double plataPoSatu;
    private double ukupanBrojSati;

    public Zaposleni(int id, String ime, String prezime, double plataPoSatu, double ukupanBrojSati) {
        this.id = id;
        this.ime = ime;
        this.prezime = prezime;
        this.plataPoSatu = plataPoSatu;
        this.ukupanBrojSati = ukupanBrojSati;
    }

    public abstract double obracunPlate();

    public int getId() {
    	return id; }
    
    public String getIme() {
    	return ime; }
    
    public String getPrezime() { 
    	return prezime; }
    
    public double getPlataPoSatu() { 
    	return plataPoSatu; }
    
    public double getUkupanBrojSati() {
    	return ukupanBrojSati; }

    public void ispis() {
        System.out.println("[" + id + "] " + ime + " " + prezime + "Plata: " + obracunPlate());
    }
}
