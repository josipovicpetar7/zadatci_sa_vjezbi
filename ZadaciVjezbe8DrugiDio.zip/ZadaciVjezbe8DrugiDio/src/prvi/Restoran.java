package prvi;

import java.util.ArrayList;

public class Restoran {
    private String naziv;
    private String adresa;
    private String pib;
    private ArrayList<Zaposleni> zaposleni = new ArrayList<>();

    public Restoran(String naziv, String adresa, String pib) {
        this.naziv = naziv;
        this.adresa = adresa;
        this.pib = pib;
    }

    public void dodajZaposlenog(Zaposleni z) {
        zaposleni.add(z);
    }

    public void prikaziZaposlene() {
        System.out.println("Zaposleni");
        for (Zaposleni z : zaposleni) {
            z.ispis();
        }
    }

    public double ukupnaPlata() {
        double suma = 0;
        for (Zaposleni z : zaposleni) {
            suma += z.obracunPlate();
        }
        return suma;
    }

    public void prikaziUkupanObracun() {
        System.out.println("Ukupan trosak plata: " + ukupnaPlata());
    }
}
