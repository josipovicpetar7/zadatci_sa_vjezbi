package prvi;

public class Main {
    public static void main(String[] args) {

        Restoran restoran = new Restoran("Bistro Kod Mire", "Njegoševa 22", "12345678");

        Zaposleni konobar = new Konobar(1, "Petar", "Ilic", 9, 170);
        Zaposleni konobar1 = new Konobar(2, "Petar", "Tadic", 8.5, 170);
        Zaposleni kuvar = new Kuvar(3, "Ana", "Markovic", 9.0, 160);
        Zaposleni kuvar1 = new Kuvar(4, "Marko", "Markovic", 9.5, 160);
        Zaposleni menadzer = new Menadzer(5, "Milan", "Jovanovic", 10.0, 160, 200);

        restoran.dodajZaposlenog(konobar);
        restoran.dodajZaposlenog(konobar1);
        restoran.dodajZaposlenog(kuvar);
        restoran.dodajZaposlenog(kuvar1);
        restoran.dodajZaposlenog(menadzer);

        restoran.prikaziZaposlene();
        restoran.prikaziUkupanObracun();
    }
}
