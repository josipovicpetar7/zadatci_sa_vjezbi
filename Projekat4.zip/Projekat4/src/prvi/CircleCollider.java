package prvi;

public class CircleCollider implements Collidable {
	
    @Override
    public boolean intersects(Collidable other) {
        return false;
    }
}
