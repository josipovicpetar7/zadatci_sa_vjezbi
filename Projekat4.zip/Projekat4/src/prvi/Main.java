package prvi;

public class Main {
    public static void main(String[] args) {

        Player p = new Player("Marko", 5, 5);

        Enemy e1 = new MeleeEnemy(10, 2, 5);
        Enemy e2 = new BossEnemy(1, 1, 20);

        Game g = new Game(p);
        g.addEnemy(e1);
        g.addEnemy(e2);

        g.printAll();
    }
}
