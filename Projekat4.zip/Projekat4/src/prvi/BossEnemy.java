package prvi;

public class BossEnemy extends Enemy {

    public BossEnemy(double x, double y, int damage) {
        super(x, y, damage);

        if (this.damage < 10) {
            this.damage = 10;
        }
    }

    @Override
    public String getDisplayName() {
        return "BossEnemy (dmg: " + damage + ")";
    }
}
