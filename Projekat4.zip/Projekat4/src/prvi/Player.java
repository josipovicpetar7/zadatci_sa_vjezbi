package prvi;

public class Player extends GameObject {

    private String name;
    private int health;

    public Player(String name, double x, double y) {
        super(x, y);

        if (name == null || name.length() == 0) {
            name = "NepoznatiIgrac";
        }

        this.name = name;
        this.health = 100;
    }

    public void setHealth(int h) {
        if (h < 0) {
            health = 0; 
        } else {
            health = h;
        }
    }

    @Override
    public String getDisplayName() {
        return "Player: " + name;
    }
}
