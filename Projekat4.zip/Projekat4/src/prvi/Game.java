package prvi;

import java.util.ArrayList;

public class Game {

    private Player player;
    private ArrayList<Enemy> enemies;

    public Game(Player p) {
        this.player = p;
        enemies = new ArrayList<>();
    }

    public void addEnemy(Enemy e) {
        enemies.add(e);
    }

    public void printAll() {
        System.out.println(player);
        for (Enemy e : enemies) {
            System.out.println(e);
        }
    }
}
