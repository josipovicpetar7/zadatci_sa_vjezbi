package prvi;

public class RectangleCollider implements Collidable {
	
    @Override
    public boolean intersects(Collidable other) {
        return false;
    }
}
