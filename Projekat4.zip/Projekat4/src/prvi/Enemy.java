package prvi;

public class Enemy extends GameObject {

    protected int damage;

    public Enemy(double x, double y, int damage) {
        super(x, y);

        if (damage < 0) {
            damage = 0;
        }
        if (damage == 0) {
            damage = 5;
        }

        this.damage = damage;
    }

    @Override
    public String getDisplayName() {
        return "Enemy (dmg: " + damage + ")";
    }
}
