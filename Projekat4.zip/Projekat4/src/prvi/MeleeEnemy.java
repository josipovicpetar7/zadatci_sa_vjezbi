package prvi;

public class MeleeEnemy extends Enemy {

    public MeleeEnemy(double x, double y, int damage) {
        super(x, y, damage + 2);
    }

    @Override
    public String getDisplayName() {
        return "MeleeEnemy (dmg: " + damage + ")";
    }
}
