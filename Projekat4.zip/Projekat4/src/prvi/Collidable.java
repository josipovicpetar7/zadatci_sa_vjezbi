package prvi;

public interface Collidable {
    boolean intersects(Collidable other);
}
