package prvi;

public class Racunari extends EProizvod{

	private String procesor;
	private int memorija;
	
	public Racunari(String sifra, String opis, double uvoznaCijena, String procesor, int memorija) {
		super(sifra, opis, uvoznaCijena);
		this.procesor = procesor;
		this.memorija = memorija;
	}

	public String getProcesor() {
		return procesor;
	}

	public void setProcesor(String procesor) {
		this.procesor = procesor;
	}

	public int getMemorija() {
		return memorija;
	}

	public void setMemorija(int memorija) {
		this.memorija = memorija;
	}
	@Override
    public double racunajMaloprodajnuCijenu() {
        return getUvoznaCijena() * 1.05;
    }
	public void ispis() {
		System.out.println("Model: " + getOpis() + ", " + "Procesor: " + procesor + ", " + "Memorija: " + memorija + ", " + "Cijena: " + racunajMaloprodajnuCijenu());
	}
}
