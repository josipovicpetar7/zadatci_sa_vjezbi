package prvi;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        EProizvod[] proizvodi = new EProizvod[10];
        int brojProizvoda = 0;

        while (true) {
            System.out.println("1.Unos uredjaja");
            System.out.println("2.Pregled svih uredjaja");
            System.out.println("3.Pregled uredjaja odredjenog tipa");
            System.out.println("0.Izlaz");
            System.out.print("Izbor: ");

            int izbor = scanner.nextInt();
            scanner.nextLine();

            if (izbor == 0) {
                System.out.println("Kraj programa");
                break;
            }

            switch (izbor) {
                case 1:
                    if (brojProizvoda >= proizvodi.length) {
                        System.out.println("Nema vise mjesta za unos");
                        break;
                    }

                    System.out.print("Unesite sifru (RA/TE/TV): ");
                    String sifra = scanner.nextLine().trim();

                    System.out.print("Opis uredjaja: ");
                    String opis = scanner.nextLine();

                    System.out.print("Uvozna cijena: ");
                    double cijena = scanner.nextDouble();
                    scanner.nextLine();

                    if (sifra.startsWith("RA")) {
                        System.out.print("Procesor: ");
                        String proc = scanner.nextLine();
                        System.out.print("Memorija (GB): ");
                        int mem = scanner.nextInt();
                        scanner.nextLine();
                        proizvodi[brojProizvoda++] = new Racunari(sifra, opis, cijena, proc, mem);
                    }
                    else if (sifra.startsWith("TE")) {
                        System.out.print("Operativni sistem: ");
                        String os = scanner.nextLine();
                        System.out.print("Velidcna ekrana (inca): ");
                        int vel = scanner.nextInt();
                        scanner.nextLine();
                        proizvodi[brojProizvoda++] = new Telefoni(sifra, opis, cijena, os, vel);
                    }
                    else if (sifra.startsWith("TV")) {
                        System.out.print("Velicina ekrana (inca): ");
                        int ekran = scanner.nextInt();
                        scanner.nextLine();
                        proizvodi[brojProizvoda++] = new TV(sifra, opis, cijena, ekran);
                    } else {
                        System.out.println("Nepoznata sifra, mora pocinjati sa RA, TE ili TV.");
                    }
                    break;

                case 2:
                    if (brojProizvoda == 0) {
                        System.out.println("Nema unesenih uredjaja");
                    } else {
                        System.out.println("SVI UREDJAJI");
                        for (int i = 0; i < brojProizvoda; i++) {
                            proizvodi[i].ispis();
                        }
                    }
                    break;

                case 3:
                    if (brojProizvoda == 0) {
                        System.out.println("Nema unesenih uredjaja.");
                        break;
                    }
                    System.out.print("Unesite tip (Racunar / Telefon / TV): ");
                    String tip = scanner.nextLine().trim();

                    System.out.println("Uredjaji tipa: " + tip);
                    boolean nadjen = false;

                    for (int i = 0; i < brojProizvoda; i++) {
                        if (proizvodi[i].getTip().equalsIgnoreCase(tip)) {
                            proizvodi[i].ispis();
                            nadjen = true;
                        }
                    }

                    if (!nadjen) {
                        System.out.println("Nema uredjaja tog tipa.");
                    }
                    break;

                default:
                    System.out.println("Pogresan izbor");
            }
        }
    }
}
