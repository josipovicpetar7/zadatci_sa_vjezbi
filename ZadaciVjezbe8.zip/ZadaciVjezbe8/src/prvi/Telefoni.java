package prvi;

public class Telefoni extends EProizvod{

	private String operativniSistem;
	private int velicinaEkrana;
	
	public Telefoni(String sifra, String opis, double uvoznaCijena, String operativniSistem, int velicinaEkrana) {
        super(sifra, opis, uvoznaCijena);
        this.operativniSistem = operativniSistem;
        this.velicinaEkrana = velicinaEkrana;
    }

	public String getOperativniSistem() {
		return operativniSistem;
	}

	public void setOperativniSistem(String operativniSistem) {
		this.operativniSistem = operativniSistem;
	}

	public int getvelicinaEkrana() {
		return velicinaEkrana;
	}

	public void setvelicinaEkrana(int velicinaEkrana) {
		this.velicinaEkrana = velicinaEkrana;
	}
	 @Override
	    public double racunajMaloprodajnuCijenu() {
	        if (velicinaEkrana > 6) {
				return getUvoznaCijena() * 1.08;
			}else {
				return getUvoznaCijena() * 1.05;
			}
	    }
	 public void ispis() {
			System.out.println("Model: " + getOpis() + ", " + "Operativni Sistem: " + operativniSistem + ", " + "Velicina Ekrana: " + velicinaEkrana + ", " + "Cijena: " + racunajMaloprodajnuCijenu());
		}
}
