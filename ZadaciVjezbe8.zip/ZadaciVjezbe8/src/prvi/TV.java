package prvi;

public class TV extends EProizvod{

	private double velicinaEkrana;
	
	public TV(String sifra, String opis, double uvoznaCijena,double velicinaEkrana) {
		super(sifra, opis, uvoznaCijena);
		this.velicinaEkrana = velicinaEkrana;
	}

	public double getVelicinaEkrana() {
		return velicinaEkrana;
	}

	public void setVelicinaEkrana(double velicinaEkrana) {
		this.velicinaEkrana = velicinaEkrana;
	}
	@Override
	public double racunajMaloprodajnuCijenu() {
		if (velicinaEkrana > 65) {
			return getUvoznaCijena() * 1.10;
		}else {
			return getUvoznaCijena() * 1.06;
		}
	}
	public void ispis() {
		System.out.println("Model: " + getOpis() + ", " + "Velicina Ekrana: " + velicinaEkrana + ", " + "Cijena: " + racunajMaloprodajnuCijenu());
	}
}
