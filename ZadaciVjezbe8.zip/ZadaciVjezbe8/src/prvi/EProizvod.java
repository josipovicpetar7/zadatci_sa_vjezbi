package prvi;

public class EProizvod {

	private String opis;
	private String sifra;
	private double uvoznaCijena;
	
	public EProizvod(String sifra, String opis, double uvoznaCijena) {
        this.sifra = sifra;
        this.opis = opis;
        this.uvoznaCijena = uvoznaCijena;
    }

	public String getOpis() {
		return opis;
	}

	public void setOpis(String opis) {
		this.opis = opis;
	}

	public String getSifra() {
		return sifra;
	}

	public void setSifra(String sifra) {
		this.sifra = sifra;
	}

	public double getUvoznaCijena() {
		return uvoznaCijena;
	}

	public void setUvoznaCijena(double uvoznaCijena) {
		this.uvoznaCijena = uvoznaCijena;
	}
	
	public double racunajMaloprodajnuCijenu() {
		return uvoznaCijena;
	}
	
	public String getTip() {
        if (sifra.startsWith("RA")) return "Racunar";
        if (sifra.startsWith("TE")) return "Telefon";
        if (sifra.startsWith("TV")) return "TV";
        return "Nepoznat tip";
    }
	public void ispis() {
		System.out.println("Opis: " + opis + ", " + "Sifra: " + sifra + ", " + "Uvozna Cijena:" + uvoznaCijena);
	}
}

